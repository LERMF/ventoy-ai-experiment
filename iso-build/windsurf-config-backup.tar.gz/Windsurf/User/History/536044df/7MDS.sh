#!/bin/bash
# WINDSURF AGENT - Script de Controle e Gerenciamento Completo
# Sistema Inteligente Autônomo com Interface de Controle

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Variáveis globais
AGENT_PID=""
LOG_FILE="/var/log/windsurf_agent.log"
STATUS_FILE="/tmp/windsurf_agent_status.json"
PYTHON_SCRIPT="/home/luiz/CascadeProjects/windsurf_agent.py"

# Função de logging
log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Verificar se é o usuário correto
check_user() {
    if [ "$USER" != "luiz" ]; then
        echo -e "${RED}❌ Este script deve ser executado como usuário 'luiz'${NC}"
        exit 1
    fi
}

# Verificar dependências
check_dependencies() {
    echo -e "${BLUE}🔍 Verificando dependências...${NC}"

    # Verificar Python
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}❌ Python 3 não encontrado${NC}"
        exit 1
    fi

    # Verificar script principal
    if [ ! -f "$PYTHON_SCRIPT" ]; then
        echo -e "${RED}❌ Script principal não encontrado: $PYTHON_SCRIPT${NC}"
        exit 1
    fi

    # Verificar sudoers
    if ! sudo -n true &> /dev/null; then
        echo -e "${YELLOW}⚠️ Configuração sudo pode precisar de ajustes${NC}"
    fi

    echo -e "${GREEN}✅ Todas as dependências verificadas${NC}"
}

# Iniciar agente
start_agent() {
    echo -e "${GREEN}🚀 Iniciando Windsurf Agent...${NC}"

    # Verificar se já está rodando
    if pgrep -f "windsurf_agent.py" > /dev/null; then
        echo -e "${YELLOW}⚠️ Agente já está rodando${NC}"
        return 1
    fi

    # Iniciar em background
    nohup python3 "$PYTHON_SCRIPT" > /dev/null 2>&1 &
    AGENT_PID=$!

    # Aguardar inicialização
    sleep 3

    if ps -p $AGENT_PID > /dev/null; then
        echo -e "${GREEN}✅ Agente iniciado com PID: $AGENT_PID${NC}"
        save_status "running" "$AGENT_PID"
        log "AGENTE INICIADO: PID=$AGENT_PID"
        return 0
    else
        echo -e "${RED}❌ Falha ao iniciar agente${NC}"
        return 1
    fi
}

# Parar agente
stop_agent() {
    echo -e "${YELLOW}⏹️ Parando Windsurf Agent...${NC}"

    if [ -f "$STATUS_FILE" ]; then
        OLD_PID=$(cat "$STATUS_FILE" | grep -o '"pid":[0-9]*' | grep -o '[0-9]*')
    fi

    # Parar processo
    if [ ! -z "$OLD_PID" ] && ps -p $OLD_PID > /dev/null; then
        kill $OLD_PID
        sleep 2
        if ps -p $OLD_PID > /dev/null; then
            kill -9 $OLD_PID
        fi
        echo -e "${GREEN}✅ Processo $OLD_PID terminado${NC}"
    fi

    # Parar outros processos relacionados
    pkill -f "windsurf_agent.py"
    sudo systemctl stop windsurf-agent.service 2>/dev/null || true

    save_status "stopped" ""
    log "AGENTE PARADO"
    echo -e "${GREEN}✅ Agente parado completamente${NC}"
}

# Status do agente
show_status() {
    echo -e "${BLUE}📊 STATUS DO WINDSURF AGENT${NC}"
    echo "================================="

    # Status do processo
    if pgrep -f "windsurf_agent.py" > /dev/null; then
        PID=$(pgrep -f "windsurf_agent.py")
        echo -e "${GREEN}✅ Agente Ativo (PID: $PID)${NC}"

        # Informações do processo
        if command -v ps &> /dev/null; then
            ps -p $PID -o pid,ppid,pcpu,pmem,etime,cmd | tail -1
        fi
    else
        echo -e "${RED}❌ Agente Não Está Rodando${NC}"
    fi

    # Status do serviço systemd
    echo ""
    echo -e "${CYAN}📋 Serviço Systemd:${NC}"
    sudo systemctl status windsurf-agent.service --no-pager 2>/dev/null || echo "Serviço não configurado"

    # Logs recentes
    echo ""
    echo -e "${PURPLE}📜 Logs Recentes:${NC}"
    if [ -f "$LOG_FILE" ]; then
        tail -10 "$LOG_FILE" | head -5
    else
        echo "Nenhum log encontrado"
    fi

    # Recursos do sistema
    echo ""
    echo -e "${YELLOW}💾 Recursos do Sistema:${NC}"
    echo "CPU: $(top -b -n1 | grep "Cpu(s)" | awk '{print $2 + $4}')% | Memória: $(free | awk 'NR==2{printf "%.1f%%", $3*100/$2 }') | Disco: $(df / | awk 'NR==2{print $5}')"
}

# Modo autônomo
autonomous_mode() {
    echo -e "${PURPLE}🤖 MODO AUTÔNOMO ATIVADO${NC}"
    echo "=========================="

    if ! pgrep -f "windsurf_agent.py" > /dev/null; then
        echo -e "${YELLOW}⚠️ Iniciando agente primeiro...${NC}"
        start_agent
    fi

    echo -e "${GREEN}✅ Monitoramento autônomo ativo${NC}"
    echo -e "${CYAN}💡 O agente está operando de forma independente${NC}"
    echo -e "${CYAN}📊 Executará otimizações automáticas conforme necessário${NC}"

    # Mostrar atividade em tempo real
    echo ""
    echo -e "${BLUE}📈 ATIVIDADE EM TEMPO REAL:${NC}"

    while pgrep -f "windsurf_agent.py" > /dev/null; do
        echo -n "$(date '+%H:%M:%S') - "
        if [ -f "$LOG_FILE" ]; then
            tail -1 "$LOG_FILE" 2>/dev/null | cut -d'-' -f4- | cut -c2- || echo "Sistema ativo"
        else
            echo "Sistema ativo"
        fi
        sleep 5
    done

    echo -e "${YELLOW}⏹️ Modo autônomo encerrado${NC}"
}

# Reinicialização de emergência
emergency_reboot() {
    echo -e "${RED}🚨 EMERGÊNCIA: REINICIALIZAÇÃO DO SISTEMA${NC}"
    echo "=========================================="

    echo -e "${RED}⚠️ Esta ação irá reiniciar o computador${NC}"
    echo -e "${YELLOW}💡 Motivo: Sistema crítico ou otimização necessária${NC}"

    read -p "Confirmar reinicialização? (SIM/nao): " confirm

    case $confirm in
        SIM|s|S|y|Y)
            echo -e "${RED}🔄 Reiniciando em 10 segundos...${NC}"
            log "REINICIALIZAÇÃO DE EMERGÊNCIA CONFIRMADA"

            # Salvar estado final
            save_status "emergency_reboot" ""

            # Contagem regressiva
            for i in {10..1}; do
                echo -n "$i... "
                sleep 1
            done

            sudo reboot
            ;;
        *)
            echo -e "${GREEN}❌ Reinicialização cancelada${NC}"
            log "REINICIALIZAÇÃO DE EMERGÊNCIA CANCELADA"
            ;;
    esac
}

# Otimizar sistema
optimize_system() {
    echo -e "${CYAN}🔧 OTIMIZAÇÃO COMPLETA DO SISTEMA${NC}"
    echo "=================================="

    # Aplicar otimizações básicas
    echo -e "${BLUE}📦 Aplicando otimizações...${NC}"

    # Atualizar sistema
    sudo apt update -qq && sudo apt upgrade -y -qq

    # Limpeza
    sudo apt autoremove -y -qq
    sudo apt autoclean -qq

    # Otimizações de kernel
    sudo sysctl -q vm.swappiness=5
    sudo sysctl -q vm.dirty_ratio=3

    # Limpeza de caches
    sudo sysctl -q vm.drop_caches=3

    # Limpeza de arquivos temporários
    sudo find /tmp -type f -mtime +1 -delete -qq 2>/dev/null || true

    echo -e "${GREEN}✅ Sistema otimizado com sucesso${NC}"
    log "OTIMIZAÇÃO DO SISTEMA EXECUTADA"
}

# Salvar status
save_status() {
    local status=$1
    local pid=$2

    cat > "$STATUS_FILE" << EOF
{
    "status": "$status",
    "pid": "$pid",
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "user": "$USER"
}
EOF
}

# Mostrar menu principal
show_menu() {
    echo -e "
${PURPLE}╔══════════════════════════════════════╗${NC}
${PURPLE}║         WINDSURF AGENT CONTROL       ║${NC}
${PURPLE}╚══════════════════════════════════════╝${NC}
${CYAN}┌──────────────────────────────────────┐${NC}
${CYAN}│ 1. 🚀 Iniciar Agente                 │${NC}
${CYAN}│ 2. ⏹️ Parar Agente                   │${NC}
${CYAN}│ 3. 📊 Status do Sistema              │${NC}
${CYAN}│ 4. 🤖 Modo Autônomo                  │${NC}
${CYAN}│ 5. 🔧 Otimizar Sistema               │${NC}
${CYAN}│ 6. 🚨 Reinicialização de Emergência  │${NC}
${CYAN}│ 7. 📜 Ver Logs                       │${NC}
${CYAN}│ 8. ❓ Ajuda                          │${NC}
${CYAN}│ 9. 👋 Sair                           │${NC}
${CYAN}└──────────────────────────────────────┘${NC}
"
}

# Função de ajuda
show_help() {
    echo -e "
${BLUE}📖 AJUDA - WINDSURF AGENT${NC}
========================

${YELLOW}COMANDOS:${NC}
  start       - Inicia o agente em background
  stop        - Para o agente completamente
  status      - Mostra status atual do agente
  autonomous  - Ativa modo de operação autônoma
  optimize    - Executa otimizações do sistema
  reboot      - Reinicialização de emergência
  logs        - Mostra logs recentes

${GREEN}RECURSOS:${NC}
  • Monitoramento em tempo real
  • Otimizações automáticas
  • Gerenciamento de recursos
  • Resposta a emergências
  • Sistema de auditoria completo

${RED}IMPORTANTE:${NC}
  • Todas as ações são auditadas
  • Emergências requerem confirmação
  • Sistema opera com menor privilégio
  • Logs salvos em /var/log/windsurf_agent.log

${CYAN}EXEMPLO DE USO:${NC}
  ./windsurf_agent.sh start
  ./windsurf_agent.sh autonomous
"
}

# Função principal
main() {
    check_user
    check_dependencies

    # Se nenhum argumento fornecido, mostrar menu
    if [ $# -eq 0 ]; then
        while true; do
            show_menu
            read -p "Escolha uma opção (1-9): " choice

            case $choice in
                1) start_agent ;;
                2) stop_agent ;;
                3) show_status ;;
                4) autonomous_mode ;;
                5) optimize_system ;;
                6) emergency_reboot ;;
                7) echo -e "${PURPLE}📜 LOGS RECENTES:${NC}"; tail -20 "$LOG_FILE" 2>/dev/null || echo "Nenhum log encontrado" ;;
                8) show_help ;;
                9) echo -e "${GREEN}👋 Até logo!${NC}"; exit 0 ;;
                *) echo -e "${RED}❌ Opção inválida${NC}" ;;
            esac

            echo ""
            read -p "Pressione Enter para continuar..."
        done
    else
        # Executar comando diretamente
        case $1 in
            start|iniciar) start_agent ;;
            stop|parar) stop_agent ;;
            status|estado) show_status ;;
            autonomous|auto) autonomous_mode ;;
            optimize|otimizar) optimize_system ;;
            reboot|reiniciar) emergency_reboot ;;
            logs|log) echo -e "${PURPLE}📜 LOGS:${NC}"; tail -20 "$LOG_FILE" 2>/dev/null || echo "Nenhum log encontrado" ;;
            help|ajuda) show_help ;;
            *) echo -e "${RED}❌ Comando inválido: $1${NC}"; show_help; exit 1 ;;
        esac
    fi
}

# Executar função principal
main "$@"
7777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777777